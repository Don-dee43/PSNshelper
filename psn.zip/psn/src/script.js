let opponents = [];

function addOpponent() {
    const name = document.getElementById('nameInput').value.trim();
    const category = document.getElementById('categorySelect').value;

    if (name) {
        opponents.push({ name, category });
        document.getElementById('nameInput').value = '';
        alert(`${name} has been added.`);
    } else {
        alert('Please enter a name.');
    }
}

function searchOpponent() {
    const query = document.getElementById('searchInput').value.toLowerCase();
    const list = document.getElementById('opponentList');
    list.innerHTML = ''; // Clear the list before adding filtered results

    if (query) {
        const filteredOpponents = opponents.filter(opponent =>
            opponent.name.toLowerCase().includes(query)
        );

        if (filteredOpponents.length > 0) {
            filteredOpponents.forEach(opponent => {
                const listItem = document.createElement('li');
                listItem.textContent = `${opponent.name} - ${opponent.category}`;
                list.appendChild(listItem);
            });
        } else {
            list.innerHTML = '<li>No opponents found.</li>';
        }
    }
}
